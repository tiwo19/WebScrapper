from flask import Flask, jsonify
import subprocess
import threading
import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables

application = Flask(__name__)

@application.route('/run', methods=['POST'])
def run_script():
    """Endpoint to trigger the long-running script"""
    def execute_script():
        try:
            # Run your script with unbuffered output for better logging
            subprocess.run(
                ['python3', '-u', 'index.py'],
                check=True
            )
        except subprocess.CalledProcessError as e:
            application.logger.error(f"Script failed: {e}")

    # Run in background thread
    thread = threading.Thread(target=execute_script)
    thread.daemon = True
    thread.start()
    
    return jsonify({
        "status": "success",
        "message": "Script started in background",
        "pid": os.getpid()
    })

@application.route('/health')
def health_check():
    """Health check endpoint for EB"""
    return jsonify({"status": "healthy"})

if __name__ == '__main__':
    application.run(host='0.0.0.0', port=8000)